import { pgTable, text, serial, integer, boolean, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  class: text("class").notNull(),
  rollNumber: text("roll_number").notNull(),
  parentName: text("parent_name").notNull(),
  contactNumber: text("contact_number").notNull(),
  address: text("address").notNull(),
  joinDate: timestamp("join_date").defaultNow().notNull(),
  lastFeePaid: date("last_fee_paid").notNull(),
  nextFeeDue: date("next_fee_due").notNull(),
  feeAmount: integer("fee_amount").default(1300).notNull(),
  smsNotificationSent: boolean("sms_notification_sent").default(false),
});

export const fees = pgTable("fees", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  month: text("month").notNull(),
  amount: integer("amount").notNull(),
  paid: boolean("paid").default(false),
  dueDate: date("due_date").notNull(),
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  smsNotificationSent: true,
  feeAmount: true,
}).extend({
  joinDate: z.coerce.date(),
  lastFeePaid: z.coerce.date(),
  nextFeeDue: z.coerce.date(),
});

export const insertFeeSchema = createInsertSchema(fees).omit({ id: true });

export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Fee = typeof fees.$inferSelect;
export type InsertFee = z.infer<typeof insertFeeSchema>;