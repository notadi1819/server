import sgMail from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  console.warn("SendGrid API key not found, notifications will be logged only");
}

if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

export async function sendFeeNotification(
  parentEmail: string,
  parentName: string,
  studentName: string,
  dueDate: Date
) {
  const message = {
    to: parentEmail,
    from: 'school@example.com', // Replace with your verified sender
    subject: 'Fee Payment Reminder',
    text: `Dear ${parentName},\n\nThis is a reminder that the school fee for ${studentName} is due on ${dueDate.toLocaleDateString()}.\n\nPlease ensure timely payment.\n\nBest regards,\nSchool Administration`,
    html: `
      <p>Dear ${parentName},</p>
      <p>This is a reminder that the school fee for <strong>${studentName}</strong> is due on <strong>${dueDate.toLocaleDateString()}</strong>.</p>
      <p>Please ensure timely payment.</p>
      <p>Best regards,<br>School Administration</p>
    `,
  };

  try {
    if (process.env.SENDGRID_API_KEY) {
      await sgMail.send(message);
      console.log(`Notification sent to ${parentEmail} for ${studentName}`);
    } else {
      // Log the notification if SendGrid is not configured
      console.log('Fee notification (no SendGrid):', message);
    }
    return true;
  } catch (error) {
    console.error('Notification error:', error);
    return false;
  }
}
