import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertStudentSchema } from "@shared/schema";
import { z } from "zod";

const updateFeeSchema = z.object({
  lastFeePaid: z.string(),
  nextFeeDue: z.string(),
});

export async function registerRoutes(app: Express) {
  // Initialize automatic fee checking
  await storage.checkAndUpdateDueFees();

  // Student routes
  app.get("/api/students", async (_req, res) => {
    const students = await storage.getStudents();
    res.json(students);
  });

  app.get("/api/students/:id", async (req, res) => {
    const student = await storage.getStudent(parseInt(req.params.id));
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  });

  app.post("/api/students", async (req, res) => {
    const result = insertStudentSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ message: "Invalid student data" });
    }
    const student = await storage.createStudent(result.data);
    res.status(201).json(student);
  });

  app.patch("/api/students/:id/pay-fee", async (req, res) => {
    const result = updateFeeSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ message: "Invalid fee update data" });
    }

    try {
      const student = await storage.updateStudentFee(
        parseInt(req.params.id),
        new Date(result.data.lastFeePaid),
        new Date(result.data.nextFeeDue)
      );
      res.json(student);
    } catch (error) {
      res.status(404).json({ message: "Student not found" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}