import { Student, InsertStudent } from "@shared/schema";
import { sendFeeNotification } from "./notifications";

export interface IStorage {
  getStudents(): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudentFee(id: number, lastFeePaid: Date, nextFeeDue: Date): Promise<Student>;
  checkAndUpdateDueFees(): Promise<void>;
}

export class MemStorage implements IStorage {
  private students: Map<number, Student>;
  private currentStudentId: number;
  private feeCheckInterval: NodeJS.Timeout;

  constructor() {
    this.students = new Map();
    this.currentStudentId = 1;
    // Check for due fees every hour
    this.feeCheckInterval = setInterval(() => this.checkAndUpdateDueFees(), 1000 * 60 * 60);
  }

  async getStudents(): Promise<Student[]> {
    return Array.from(this.students.values());
  }

  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = this.currentStudentId++;
    const student: Student = {
      ...insertStudent,
      id,
      feeAmount: 1300,
      smsNotificationSent: false,
      joinDate: new Date(insertStudent.joinDate),
      lastFeePaid: new Date(insertStudent.lastFeePaid),
      nextFeeDue: new Date(insertStudent.nextFeeDue),
    };
    this.students.set(id, student);
    return student;
  }

  async updateStudentFee(
    id: number,
    lastFeePaid: Date,
    nextFeeDue: Date
  ): Promise<Student> {
    const student = this.students.get(id);
    if (!student) throw new Error("Student not found");

    const updatedStudent = {
      ...student,
      lastFeePaid,
      nextFeeDue,
      smsNotificationSent: false,
    };
    this.students.set(id, updatedStudent);
    return updatedStudent;
  }

  async checkAndUpdateDueFees(): Promise<void> {
    const currentDate = new Date();

    for (const student of this.students.values()) {
      const dueDate = new Date(student.nextFeeDue);

      // If fee is due and notification hasn't been sent
      if (dueDate <= currentDate && !student.smsNotificationSent) {
        // Send notification
        await sendFeeNotification(
          student.contactNumber, // Using contact number as email for now
          student.parentName,
          student.name,
          dueDate
        );

        // Mark fee as unpaid and update notification status
        const updatedStudent = {
          ...student,
          smsNotificationSent: true,
          lastFeePaid: new Date(0), // Reset last paid date
          nextFeeDue: currentDate, // Set due date to current date
        };
        this.students.set(student.id, updatedStudent);
      }
    }
  }
}

export const storage = new MemStorage();