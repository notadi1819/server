import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { GraduationCap, Users, Sun, Moon } from "lucide-react";
import { useTheme } from "@/components/theme-provider";

export default function Navbar() {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  const links = [
    { href: "/", label: "Dashboard", icon: GraduationCap },
    { href: "/students", label: "Students", icon: Users },
  ];

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/">
              <img 
                src="Yellow cute illustration Kids Learning Center Logo.png"
                alt="Learn Says Fun"
                className="h-12 w-auto cursor-pointer"
              />
            </Link>
            <div className="flex space-x-4">
              {links.map(({ href, label, icon: Icon }) => (
                <Link key={href} href={href}>
                  <span
                    className={cn(
                      "flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-md cursor-pointer",
                      location === href
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-muted"
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{label}</span>
                  </span>
                </Link>
              ))}
            </div>
          </div>
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="p-2 rounded-md hover:bg-muted"
          >
            {theme === "dark" ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>
    </nav>
  );
}