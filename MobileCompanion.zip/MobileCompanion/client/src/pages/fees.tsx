import { useQuery } from "@tanstack/react-query";
import { Student, Fee } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import FeeForm from "@/components/fee-form";

export default function Fees() {
  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  if (studentsLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Fee Management</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Fee
            </Button>
          </DialogTrigger>
          <DialogContent>
            <div className="mb-4">
              <h2 className="text-lg font-semibold">Add New Fee</h2>
              <p className="text-sm text-muted-foreground">Monthly fee amount is fixed at ₹1,300</p>
            </div>
            <FeeForm students={students || []} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {students?.map((student) => (
          <StudentFeeCard key={student.id} student={student} />
        ))}
      </div>
    </div>
  );
}

function StudentFeeCard({ student }: { student: Student }) {
  const { data: fees } = useQuery<Fee[]>({
    queryKey: ["/api/students", student.id, "fees"],
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>{student.name}</CardTitle>
        <div className="text-sm text-muted-foreground">
          Roll Number: {student.rollNumber}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {fees?.map((fee) => (
            <div
              key={fee.id}
              className="flex items-center justify-between py-2 border-b last:border-0"
            >
              <div>
                <div className="font-medium">{fee.month}</div>
                <div className="text-sm text-muted-foreground">
                  Fixed Fee: ₹1,300
                </div>
              </div>
              <Badge variant={fee.paid ? "default" : "destructive"}>
                {fee.paid ? "Paid" : "Unpaid"}
              </Badge>
            </div>
          ))}
          {(!fees || fees.length === 0) && (
            <div className="text-sm text-muted-foreground">
              No fee records found
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}