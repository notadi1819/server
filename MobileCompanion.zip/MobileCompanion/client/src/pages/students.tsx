import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Student } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Search, CalendarClock } from "lucide-react";
import StudentForm from "@/components/student-form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Students() {
  const [search, setSearch] = useState("");
  const { toast } = useToast();
  const { data: students, isLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const updateFeeMutation = useMutation({
    mutationFn: async ({ studentId, isPaid }: { studentId: number; isPaid: boolean }) => {
      const today = new Date();
      const nextMonth = new Date(today.setMonth(today.getMonth() + 1));

      await apiRequest("PATCH", `/api/students/${studentId}/pay-fee`, {
        lastFeePaid: isPaid ? today.toISOString() : new Date(0).toISOString(),
        nextFeeDue: isPaid ? nextMonth.toISOString() : today.toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({
        title: "Success",
        description: "Fee status updated successfully",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update fee status",
      });
    },
  });

  const filteredStudents = students?.filter(
    (student) =>
      student.name.toLowerCase().includes(search.toLowerCase()) ||
      student.rollNumber.toLowerCase().includes(search.toLowerCase())
  );

  const currentDate = new Date();

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Students</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="lg" className="px-6">
              <Plus className="mr-2 h-5 w-5" />
              Add Student
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <StudentForm />
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex w-full max-w-sm items-center space-x-2">
        <Search className="h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search students..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Roll Number</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>Parent Name</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Fee Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center">
                  Loading...
                </TableCell>
              </TableRow>
            ) : (
              filteredStudents?.map((student) => {
                const isDue = new Date(student.nextFeeDue) < currentDate;
                return (
                  <TableRow key={student.id}>
                    <TableCell>{student.rollNumber}</TableCell>
                    <TableCell>{student.name}</TableCell>
                    <TableCell>{student.class}</TableCell>
                    <TableCell>{student.parentName}</TableCell>
                    <TableCell>{student.contactNumber}</TableCell>
                    <TableCell>
                      <Badge
                        variant={isDue ? "destructive" : "default"}
                        className="flex w-fit items-center gap-1"
                      >
                        {isDue && <CalendarClock className="h-3 w-3" />}
                        {isDue ? "Payment Due" : "Paid"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => 
                          updateFeeMutation.mutate({ 
                            studentId: student.id, 
                            isPaid: isDue 
                          })
                        }
                        disabled={updateFeeMutation.isPending}
                      >
                        {isDue ? "Mark as Paid" : "Mark as Unpaid"}
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}