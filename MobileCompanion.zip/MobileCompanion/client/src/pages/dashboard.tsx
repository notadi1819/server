import { useQuery } from "@tanstack/react-query";
import { Student } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarClock } from "lucide-react";

export default function Dashboard() {
  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  if (studentsLoading) {
    return <DashboardSkeleton />;
  }

  const totalStudents = students?.length || 0;
  const currentDate = new Date();
  const studentsWithPendingFees = students?.filter(
    (student) => new Date(student.nextFeeDue) < currentDate
  ) || [];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">School Dashboard</h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Total Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalStudents}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pending Fees</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-destructive">
              {studentsWithPendingFees.length}
            </div>
            <div className="text-sm text-muted-foreground">
              Students with pending fees
            </div>
          </CardContent>
        </Card>
      </div>

      {studentsWithPendingFees.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Students with Pending Fees</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {studentsWithPendingFees.map((student) => (
              <Card key={student.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold">{student.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        Roll Number: {student.rollNumber}
                      </p>
                    </div>
                    <Badge variant="destructive" className="flex items-center gap-1">
                      <CalendarClock className="h-3 w-3" />
                      Due
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <p>Parent: {student.parentName}</p>
                    <p>Contact: {student.contactNumber}</p>
                    <p>Due Date: {new Date(student.nextFeeDue).toLocaleDateString()}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8">
      <div className="h-10 w-48 bg-muted rounded animate-pulse" />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 2 }).map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <div className="h-6 w-32 bg-muted rounded animate-pulse" />
            </CardHeader>
            <CardContent>
              <div className="h-8 w-16 bg-muted rounded animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}